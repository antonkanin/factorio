data:extend({
  {
    type = "item",
    name = "long-fast-inserter",
    icon = "__Long Inserters__/graphics/icons/long-fast-inserter.png",
    icon_size = 32,
    subgroup = "inserter",
    order = "d[fast-inserter]z",
    place_result = "long-fast-inserter",
    stack_size = 50
  },
  {
    type = "item",
    name = "long-burner-inserter",
    icon = "__Long Inserters__/graphics/icons/long-burner-inserter.png",
    icon_size = 32,
    subgroup = "inserter",
    order = "a[burner-inserter]z",
    place_result = "long-burner-inserter",
    stack_size = 50
  },
  {
    type = "item",
    name = "long-filter-inserter",
    icon = "__Long Inserters__/graphics/icons/long-filter-inserter.png",
    icon_size = 32,
    subgroup = "inserter",
    order = "e[filter-inserter]z",
    place_result = "long-filter-inserter",
    stack_size = 50
  },
  {
    type = "item",
    name = "long-stack-inserter",
    icon = "__Long Inserters__/graphics/icons/long-stack-inserter.png",
    icon_size = 32,
    subgroup = "inserter",
    order = "f[stack-inserter]z",
    place_result = "long-stack-inserter",
    stack_size = 50
  },
  {
    type = "item",
    name = "long-stack-filter-inserter",
    icon = "__Long Inserters__/graphics/icons/long-stack-filter-inserter.png",
    icon_size = 32,
    subgroup = "inserter",
    order = "g[stack-filter-inserter]z",
    place_result = "long-stack-filter-inserter",
    stack_size = 50
  }
})