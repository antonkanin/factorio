# Factorio_Better-Inserters

This Mod adds inserter capacity bonus for normal insertes to 25,50,75,100 and stack inserters to 50,100,150,200.

[https://mods.factorio.com/mods/DerMistkaefer/BetterInserters](https://mods.factorio.com/mods/DerMistkaefer/BetterInserters)

## Changelog

[Factorio Changelog File](../blob/master/changelog.txt)
